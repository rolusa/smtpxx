__author__ = "Zhang Huangbin"
__author_mail__ = "zhb@iredmail.org"
__version__ = "2.6"
